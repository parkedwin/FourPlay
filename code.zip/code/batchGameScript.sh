mkdir game1
python fourplayWebAutomate.py game1 HARD alpha
rm -rf game1

mkdir game2
python fourplayWebAutomate.py game2 HARD alpha
rm -rf game2

mkdir game3
python fourplayWebAutomate.py game3 HARD alpha
rm -rf game3

mkdir game4
python fourplayWebAutomate.py game4 HARD alpha
rm -rf game4

mkdir game5
python fourplayWebAutomate.py game5 HARD alpha
rm -rf game5

mkdir game6
python fourplayWebAutomate.py game6 HARD alpha
rm -rf game6

mkdir game7
python fourplayWebAutomate.py game7 HARD alpha
rm -rf game7

mkdir game8
python fourplayWebAutomate.py game8 HARD alpha
rm -rf game8

mkdir game9
python fourplayWebAutomate.py game9 HARD alpha
rm -rf game9

mkdir game10
python fourplayWebAutomate.py game10 HARD alpha
rm -rf game10

